"""SQLite-backed CountryBlockingIndex with bounded Python state."""
import json
import math
import os
import sqlite3
from collections.abc import Mapping

try:
    from blocking import (CountryBlockingIndex, MAX_POSTING_LIST_LEN,
                          MAX_NGRAM_POSTING_LEN, MAX_ADDR_TOKEN_POSTING_LEN,
                          MAX_PHON_POSTING_LEN, MAX_TRLIT_POSTING_LEN)
except ImportError:
    from solution.business_entity_resolution.src.blocking import (
        CountryBlockingIndex, MAX_POSTING_LIST_LEN, MAX_NGRAM_POSTING_LEN,
        MAX_ADDR_TOKEN_POSTING_LEN, MAX_PHON_POSTING_LEN, MAX_TRLIT_POSTING_LEN)

_CHANNELS = {
    'exact_name_idx': 'exact', 'compound_addr_idx': 'addr',
    'token_idx': 'token', 'prefix_idx': 'prefix', 'ngram_idx': 'ngram',
    'acronym_idx': 'acronym', 'tok_post_idx': 'tokpost',
    'addr_token_idx': 'addr_tok', 'tr_name_idx': 'tr_name',
    'tr_token_idx': 'tr_tok', 'phon_idx': 'phon', 'phone_idx': 'phone',
}
_LIMITS = {
    'token': MAX_POSTING_LIST_LEN, 'prefix': MAX_POSTING_LIST_LEN,
    'acronym': MAX_POSTING_LIST_LEN, 'tokpost': MAX_POSTING_LIST_LEN,
    'tr_tok': MAX_TRLIT_POSTING_LEN, 'tr_name': MAX_TRLIT_POSTING_LEN,
    'phon': MAX_PHON_POSTING_LEN, 'addr': MAX_POSTING_LIST_LEN,
    'ngram': MAX_NGRAM_POSTING_LEN, 'addr_tok': MAX_ADDR_TOKEN_POSTING_LEN,
}


def _key(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


class _Posting:
    def __init__(self, owner, channel, key):
        self.owner, self.channel, self.key = owner, channel, key

    def append(self, eid):
        self.owner._pending.append((self.channel, self.key, self.owner._rid))
        if len(self.owner._pending) >= 20000:
            self.owner._flush()

    def __iter__(self):
        return (row[0] for row in self.owner.db.execute(
            'SELECT r.eid FROM postings p JOIN records r ON r.rid=p.rid '
            'WHERE p.channel=? AND p.key=? ORDER BY p.seq', (self.channel, self.key)))


class _PostingMap(Mapping):
    def __init__(self, owner, channel):
        self.owner, self.channel = owner, channel

    def __getitem__(self, key):
        k = _key(key)
        if not self.owner._building and not self.__contains__(key):
            raise KeyError(key)
        return _Posting(self.owner, self.channel, k)

    def __contains__(self, key):
        return self.owner.db.execute(
            'SELECT 1 FROM key_counts WHERE channel=? AND key=?',
            (self.channel, _key(key))).fetchone() is not None

    def __iter__(self):
        return (json.loads(row[0]) for row in self.owner.db.execute(
            'SELECT key FROM key_counts WHERE channel=?', (self.channel,)))

    def __len__(self):
        return self.owner.db.execute(
            'SELECT count(*) FROM key_counts WHERE channel=?', (self.channel,)).fetchone()[0]


class _IdfMap(Mapping):
    def __init__(self, owner, channel):
        self.owner, self.channel = owner, channel

    def __getitem__(self, key):
        count = self.owner.db.execute(
            'SELECT n FROM key_counts WHERE channel=? AND key=?',
            (self.channel, _key(key))).fetchone()
        if count is None:
            raise KeyError(key)
        value = math.log((self.owner._n + 1.0) / (count[0] + 1.0))
        if self.channel == 'ngram':
            return value + 1.0
        return min(8.0, max(1.5, value)) if self.channel == 'addr' else min(8.0, value)

    def __iter__(self):
        return iter(())

    def __len__(self):
        return 0


class _Records(Mapping):
    def __init__(self, owner):
        self.owner = owner

    def __setitem__(self, eid, value):
        row = self.owner.db.execute(
            'INSERT INTO records(eid, payload) VALUES (?, ?)',
            (eid, json.dumps(value, ensure_ascii=False, separators=(',', ':'))))
        self.owner._rid = row.lastrowid
        self.owner._n += 1

    def __getitem__(self, eid):
        row = self.owner.db.execute('SELECT payload FROM records WHERE eid=?', (eid,)).fetchone()
        if row is None:
            raise KeyError(eid)
        data = json.loads(row[0])
        return (data[0], data[1], data[2], data[3], data[4], data[5])

    def __iter__(self):
        return (row[0] for row in self.owner.db.execute('SELECT eid FROM records'))

    def __len__(self):
        return self.owner._n


class DiskCountryBlockingIndex(CountryBlockingIndex):
    def __init__(self, country, db_path, create=False):
        super().__init__(country)
        self.path = os.fspath(db_path)
        self._building = create
        self._pending = []
        self._rid = 0
        if create:
            self._build_path = self.path + '.building'
            if os.path.exists(self._build_path):
                os.remove(self._build_path)
            self.db = sqlite3.connect(self._build_path)
            self.db.execute('PRAGMA journal_mode=DELETE')
            self.db.execute('PRAGMA synchronous=NORMAL')
            self.db.execute('PRAGMA temp_store=FILE')
            self.db.execute('PRAGMA cache_size=-16384')
            self.db.executescript('CREATE TABLE records(rid INTEGER PRIMARY KEY, eid TEXT UNIQUE, payload TEXT);'
                                  'CREATE TABLE postings(seq INTEGER PRIMARY KEY, channel TEXT, key TEXT, rid INTEGER);'
                                  'CREATE TABLE key_counts(channel TEXT, key TEXT, n INTEGER, '
                                  'PRIMARY KEY(channel,key)) WITHOUT ROWID;'
                                  'CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT);')
            self._n = 0
        else:
            self.db = sqlite3.connect('file:' + os.path.abspath(self.path) + '?mode=ro', uri=True)
            self.db.execute('PRAGMA cache_size=-16384')
            self.db.execute('PRAGMA temp_store=FILE')
            meta = dict(self.db.execute('SELECT k,v FROM meta'))
            if meta.get('ready') != '1' or meta.get('country') != country:
                raise ValueError('Index is incomplete or country does not match')
            self._n = int(meta['records'])
        self.records = _Records(self)
        for attr, channel in _CHANNELS.items():
            setattr(self, attr, _PostingMap(self, channel))
        self.compound_idf = _IdfMap(self, 'addr')
        self.ngram_idf = _IdfMap(self, 'ngram')
        self.addr_token_idf = _IdfMap(self, 'addr_tok')

    def _flush(self):
        if self._pending:
            self.db.executemany('INSERT INTO postings(channel,key,rid) VALUES (?,?,?)', self._pending)
            self._pending.clear()
            self.db.commit()

    def prune_frequent_keys(self):
        self._flush()
        self.db.execute('CREATE INDEX posting_lookup ON postings(channel,key,seq)')
        self.db.execute('INSERT INTO key_counts SELECT channel,key,count(*) FROM postings GROUP BY channel,key')
        for channel, limit in _LIMITS.items():
            self.db.execute('DELETE FROM key_counts WHERE channel=? AND n>?', (channel, limit))
        self.db.execute('INSERT INTO meta VALUES (?,?)', ('country', self.country))
        self.db.execute('INSERT INTO meta VALUES (?,?)', ('records', str(self._n)))
        self.db.execute('INSERT INTO meta VALUES (?,?)', ('ready', '1'))
        self.db.commit()
        self.db.close()
        os.replace(self._build_path, self.path)
        self.db = sqlite3.connect('file:' + os.path.abspath(self.path) + '?mode=ro', uri=True)
        self.db.execute('PRAGMA cache_size=-16384')
        self.db.execute('PRAGMA temp_store=FILE')
        self._building = False

    def close(self):
        if self._building:
            self._flush()
        self.db.close()
