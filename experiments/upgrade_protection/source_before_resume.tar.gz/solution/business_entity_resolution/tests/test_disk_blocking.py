import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1] / 'src'))
from blocking import CountryBlockingIndex
from disk_blocking import DiskCountryBlockingIndex
from features import compute_candidate_features_for_s1
from features2 import extra_batch_for_s1


def test_disk_index_parity(tmp_path):
    memory = CountryBlockingIndex('India')
    disk = DiskCountryBlockingIndex('India', tmp_path / 'index.sqlite', create=True)
    rows = [
        ('a', 'tata consultancy services', ['tata', 'consultancy', 'services'],
         '12 main street 560001', [('main', '12')], {12}, 1, '12 Main Street 560001', ''),
        ('b', 'tata consulting', ['tata', 'consulting'],
         '13 main street 560001', [('main', '13')], {13}, 0, '13 Main Street 560001', ''),
        ('c', 'wipro technologies', ['wipro', 'technologies'],
         '12 main street 560001', [('main', '12')], {12}, 1, '12 Main Street 560001', ''),
        ('d', 'acme labs', ['acme', 'labs'], 'elsewhere', [], set(), 0, '', ''),
    ]
    for index in (memory, disk):
        for row in rows:
            index.add_target_record(*row)
        index.prune_frequent_keys()
    disk.close()
    disk = DiskCountryBlockingIndex('India', tmp_path / 'index.sqlite')
    args = ('tata consultancy services', ['tata', 'consultancy', 'services'],
            '12 main street 560001', [('main', '12')])
    opts = dict(s1_raw_addr='12 Main Street 560001', max_candidates=3,
                return_weights=True, return_provenance=True, adaptive=True)
    left, lp = memory.query_candidates(*args, **opts)
    right, rp = disk.query_candidates(*args, **opts)
    assert [x[0] for x in left] == [x[0] for x in right]
    assert [x[1] for x in left] == [x[1] for x in right]
    assert lp == rp
    s1 = {'norm_name': args[0], 'norm_addr': args[2], 'core_tokens': args[1], 'addr_tokens': set(args[2].split()), 'digits': {'12', '560001'}}
    assert compute_candidate_features_for_s1(s1.copy(), left, memory.records) == compute_candidate_features_for_s1(s1.copy(), right, disk.records)
    l_extra = extra_batch_for_s1(s1.copy(), left, memory.records, prov_map=lp)
    r_extra = extra_batch_for_s1(s1.copy(), right, disk.records, prov_map=rp)
    assert l_extra[0] == r_extra[0]
    assert (l_extra[1] == r_extra[1]).all() if hasattr(l_extra[1], 'shape') else l_extra[1] == r_extra[1]
    assert len(l_extra[1][0]) == 22
    assert disk.query_candidates('', [], '', [], return_weights=True, return_provenance=True) == ([], {})
    disk.close()
