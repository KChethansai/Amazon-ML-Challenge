#!/usr/bin/env python3
"""Natural-India gate: end-to-end F0.5 on 1k holdout S1 vs FULL India target pool."""
import os, sys, json, time, resource
import numpy as np
sys.path.insert(0, "solution/business_entity_resolution/src")
from normalization import normalize_name, extract_name_tokens, normalize_address, extract_address_digits, extract_address_blocking_keys
from disk_blocking import DiskCountryBlockingIndex
from train import calculate_macro_f05, evaluate_metrics, query_for_s1, featurize_s1
from graph import apply_graph_bridge
import lightgbm as lgb

TRAIN_DIR = "dataset/train"
N_S1 = 1000


def main(models_dir="solution/business_entity_resolution/models"):
    t0 = time.time()
    with open("experiments/splits/holdout_s1_ids.json") as f:
        hold = json.load(f)
    hold_set = set(hold)
    gt = {}
    with open(os.path.join(TRAIN_DIR, "train_ground_truth.tsv"), encoding="utf-8") as f:
        next(f)
        for line in f:
            p = line.rstrip("\n").split("\t")
            if p[0] in hold_set:
                gt[p[0]] = set(x.strip() for x in (p[1] if len(p) > 1 else "").split(",") if x.strip())
    with open(models_dir + "/config.json") as f:
        cfg = json.load(f)
    model = lgb.Booster(model_file=models_dir + "/lgbm_matcher.txt")
    index_path = "experiments/final_scratch/india_train.sqlite"
    create = not os.path.isfile(index_path)
    idx = DiskCountryBlockingIndex("India", index_path, create=create)
    if create:
        indexed = 0
        for fn, is_s2 in [("train_source2.tsv", 1), ("train_source3.tsv", 0)]:
            with open(os.path.join(TRAIN_DIR, fn), encoding="utf-8") as f:
                next(f)
                for line in f:
                    p = line.rstrip("\n").split("\t")
                    if len(p) >= 4 and p[3] == "India":
                        nn = normalize_name(p[1]); ct, _ = extract_name_tokens(nn)
                        na = normalize_address(p[2])
                        idx.add_target_record(p[0], nn, ct, na, extract_address_blocking_keys(p[2], na),
                                              extract_address_digits(p[2]), is_s2=is_s2, raw_addr=p[2], raw_name=p[1])
                        indexed += 1
                        if indexed % 250000 == 0:
                            print(f"indexed {indexed:,} India targets in {time.time()-t0:.0f}s", flush=True)
        idx.prune_frequent_keys()
    print(f"india index: {len(idx.records)} targets in {time.time()-t0:.0f}s", flush=True)
    # select 1k india holdout s1
    sub = []
    with open(os.path.join(TRAIN_DIR, "train_source1.tsv"), encoding="utf-8") as f:
        next(f)
        for line in f:
            p = line.rstrip("\n").split("\t")
            if p[0] in hold_set and p[3] == "India":
                nn = normalize_name(p[1]); ct, _ = extract_name_tokens(nn)
                na = normalize_address(p[2]); dg = extract_address_digits(p[2])
                sub.append((p[0], {"name": p[1], "norm_name": nn, "core_tokens": ct, "addr": p[2],
                    "norm_addr": na, "addr_keys": extract_address_blocking_keys(p[2], na), "digits": dg,
                    "prefix6": nn[:6], "street_num": "", "postal": "", "country": "India"}))
                if len(sub) >= N_S1:
                    break
    gt_map, pred_map = {}, {}
    hits = tot = zero_rec = full_rec = non_singletons = 0
    candidate_counts = []
    for sid, r in sub:
        g = gt.get(sid, set())
        items, prov = query_for_s1(idx, r, max_candidates=cfg.get("max_candidates", 60), adaptive=cfg.get("adaptive", True))
        cs = {c for c, _ in items}
        candidate_counts.append(len(cs))
        rec = len(g & cs)
        hits += rec; tot += len(g)
        if g:
            non_singletons += 1
            full_rec += rec == len(g)
            zero_rec += rec == 0
        vc, fr = featurize_s1(r, items, prov, idx, use_extra=cfg.get("use_extra", True))
        if fr:
            pr_ = model.predict(np.array(fr, dtype=np.float32))
            mp = float(np.max(pr_))
            if mp < cfg["tau_singleton"]:
                pred_map[sid] = set()
            else:
                co = max(cfg["tau_min"], mp - cfg["delta_margin"])
                matches = [c for c, p_ in zip(vc, pr_) if p_ >= co]
                if cfg.get("use_graph", False):
                    pmap = {c: float(p_) for c, p_ in zip(vc, pr_)}
                    for b in apply_graph_bridge(r, matches, pmap, idx, model, use_extra=cfg.get("use_extra", True),
                                                score_min=cfg.get("graph_score_min", 0.999), bridge_min=cfg.get("graph_bridge_min", 80)):
                        if b not in matches:
                            matches.append(b)
                pred_map[sid] = set(matches)
        else:
            pred_map[sid] = set()
        gt_map[sid] = g
    m = evaluate_metrics(gt_map, pred_map)
    m["candidate_recall"] = hits / max(1, tot)
    m["entity_full_recall"] = full_rec / max(1, non_singletons)
    m["non_singleton_s1"] = non_singletons
    m["zero_recovery_s1"] = zero_rec
    m["candidate_count"] = sum(candidate_counts)
    m["candidate_count_stats"] = {
        "min": min(candidate_counts, default=0),
        "mean": float(np.mean(candidate_counts)) if candidate_counts else 0.0,
        "p50": float(np.percentile(candidate_counts, 50)) if candidate_counts else 0.0,
        "p95": float(np.percentile(candidate_counts, 95)) if candidate_counts else 0.0,
        "max": max(candidate_counts, default=0),
    }
    m["runtime_seconds"] = round(time.time() - t0, 1)
    m["peak_rss_bytes"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
    print(json.dumps(m, indent=2), flush=True)
    with open("experiments/eval_natural_latest.json", "w") as f:
        json.dump(m, f, indent=2)
    idx.close()

if __name__ == "__main__":
    main(*sys.argv[1:])
